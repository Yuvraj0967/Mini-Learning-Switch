#!/usr/bin/env python3
"""
Network Delay Measurement Tool - Analysis & Reporting
Project 15 | Computer Networks Lab

Reads logs/rtt_results.json produced by network_topology.py
and prints a formatted console report with:
  • Per-pair RTT summary (min/avg/max/mdev)
  • Delay variation (jitter = mdev)
  • Path comparison (h1→h2 expected ≈60ms vs h1→h3 through s3 ≈120ms)
  • Pass/Fail assertion vs configured link delays
"""

import json
import os
import sys
import math

RESULTS_FILE = os.path.join("logs", "rtt_results.json")

# ── Expected RTT boundaries (ms) based on topology config ────────────────
# Each hop adds delay in both directions (RTT = 2 × one-way delay)
EXPECTED = {
    # h1(10ms)─s1─(10ms)s2─(10ms)h2  → one-way 30ms → RTT ≈ 60ms
    "h1_h2": {"min": 55,  "max": 80},
    # h1(10ms)─s1─(20ms)s3─(5ms)h3   → one-way 35ms → RTT ≈ 70ms
    "h1_h3": {"min": 60,  "max": 90},
    # h1(10ms)─s1─(5ms)h4             → one-way 15ms → RTT ≈ 30ms
    "h1_h4": {"min": 25,  "max": 45},
    # h2(10ms)─s2─(20ms)s3─(5ms)h3   → one-way 35ms → RTT ≈ 70ms
    "h2_h3": {"min": 60,  "max": 90},
    # h2(10ms)─s2─(10ms)s1─(5ms)h4   → one-way 25ms → RTT ≈ 50ms
    "h2_h4": {"min": 40,  "max": 65},
    # h3(5ms)─s3─(20ms)s1─(5ms)h4    → one-way 30ms → RTT ≈ 60ms
    "h3_h4": {"min": 50,  "max": 80},
}

# ─────────────────────────────────────────────────────────────────────────
def load_results():
    if not os.path.exists(RESULTS_FILE):
        print(f"[ERROR] Results file not found: {RESULTS_FILE}")
        print("  Run network_topology.py first to generate measurements.")
        sys.exit(1)
    with open(RESULTS_FILE) as f:
        return json.load(f)


def bar(value, scale=2.0, width=40):
    """Simple ASCII bar proportional to value."""
    filled = min(int(value / scale), width)
    return "█" * filled + "░" * (width - filled)


def check(pair_key, avg):
    """Return PASS/FAIL based on expected range."""
    exp = EXPECTED.get(pair_key)
    if exp is None:
        return "  N/A "
    if exp["min"] <= avg <= exp["max"]:
        return " PASS "
    return " FAIL "


# ─────────────────────────────────────────────────────────────────────────
def print_report(data):
    results       = data.get("results", {})
    delays_config = data.get("delays_config", {})
    timestamp     = data.get("timestamp", "unknown")

    W = 70
    print("\n" + "═" * W)
    print(f"  NETWORK DELAY MEASUREMENT REPORT")
    print(f"  Generated: {timestamp}")
    print("═" * W)

    # ── Topology config ──
    print("\n  ▸ Link Delay Configuration")
    print("  " + "─" * 40)
    for link, delay in delays_config.items():
        print(f"    {link:<12}  {delay}")

    # ── RTT Table ──
    print("\n  ▸ RTT Summary (all host pairs)")
    print("  " + "─" * 66)
    print(f"  {'Pair':<10} {'Min(ms)':>8} {'Avg(ms)':>8} {'Max(ms)':>8} "
          f"{'Jitter':>8}  {'Status':>6}")
    print("  " + "─" * 66)

    sorted_pairs = sorted(results.keys())
    for pair in sorted_pairs:
        r = results[pair]
        display = pair.replace("_", "→")
        if r:
            status = check(pair, r["avg"])
            print(
                f"  {display:<10} {r['min']:>8.2f} {r['avg']:>8.2f} "
                f"{r['max']:>8.2f} {r['mdev']:>8.2f}  [{status}]"
            )
        else:
            print(f"  {display:<10} {'N/A':>8} {'N/A':>8} {'N/A':>8} {'N/A':>8}  [  ERR ]")

    # ── Bar chart ──
    print("\n  ▸ Average RTT – Visual Comparison")
    print("  " + "─" * 66)
    for pair in sorted_pairs:
        r = results[pair]
        display = pair.replace("_", "→")
        if r:
            avg = r["avg"]
            b = bar(avg, scale=2.0, width=35)
            print(f"  {display:<10} {b} {avg:>6.1f} ms")
        else:
            print(f"  {display:<10} {'[no data]'}")

    # ── Path comparison h1→h2 ──
    print("\n  ▸ Path Analysis: h1 → h2 (Direct vs Via-s3)")
    print("  " + "─" * 66)
    r12 = results.get("h1_h2")
    r13 = results.get("h1_h3")
    if r12:
        print(f"    Direct path (h1-s1-s2-h2)  avg RTT = {r12['avg']:.2f} ms")
    if r13:
        print(f"    Via s3      (h1-s1-s3-h3)  avg RTT = {r13['avg']:.2f} ms")
    if r12 and r13:
        diff = abs(r13["avg"] - r12["avg"])
        print(f"    Δ delay (extra hops penalty) ≈ {diff:.2f} ms")

    # ── Delay variation analysis ──
    print("\n  ▸ Jitter / Delay Variation Analysis")
    print("  " + "─" * 66)
    for pair in sorted_pairs:
        r = results[pair]
        display = pair.replace("_", "→")
        if r:
            variation_pct = (r["mdev"] / r["avg"] * 100) if r["avg"] else 0
            level = ("LOW" if variation_pct < 5
                     else "MEDIUM" if variation_pct < 15
                     else "HIGH")
            print(f"    {display:<10}  mdev={r['mdev']:.2f} ms  "
                  f"({variation_pct:.1f}% of avg)  → {level} jitter")

    # ── Overall summary ──
    print("\n  ▸ Validation Summary")
    print("  " + "─" * 66)
    pass_count = 0
    fail_count = 0
    for pair in sorted_pairs:
        r = results[pair]
        if r and pair in EXPECTED:
            exp = EXPECTED[pair]
            if exp["min"] <= r["avg"] <= exp["max"]:
                pass_count += 1
            else:
                fail_count += 1

    print(f"    Tests PASSED : {pass_count}")
    print(f"    Tests FAILED : {fail_count}")
    overall = "✔ ALL PASS" if fail_count == 0 else "✘ SOME FAILURES DETECTED"
    print(f"    Overall      : {overall}")
    print("\n" + "═" * W + "\n")


# ─────────────────────────────────────────────────────────────────────────
def main():
    data = load_results()
    print_report(data)


if __name__ == "__main__":
    main()
