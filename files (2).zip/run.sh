#!/bin/bash
# ============================================================
#  Network Delay Measurement Tool – Run Script
#  Project 15 | Computer Networks Lab
# ============================================================
#  Usage:
#    chmod +x run.sh
#    sudo ./run.sh
#
#  Steps:
#    1. Clean up any previous Mininet state
#    2. Start Ryu controller in background
#    3. Launch Mininet topology + measurements
#    4. Run analysis report
#    5. Optionally open Wireshark capture
# ============================================================

set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="$PROJECT_DIR/logs"
CONTROLLER="$PROJECT_DIR/controller/delay_controller.py"
TOPOLOGY="$PROJECT_DIR/topology/network_topology.py"
ANALYSIS="$PROJECT_DIR/analysis/analyze_results.py"
RYU_PORT=6633

mkdir -p "$LOG_DIR"

# ── Colour helpers ──────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'
RED='\033[0;31m';   RESET='\033[0m'
info()  { echo -e "${GREEN}[INFO]${RESET} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${RESET} $1"; }
error() { echo -e "${RED}[ERR ]${RESET} $1"; }

# ── 1. Cleanup ──────────────────────────────────────────────
info "Cleaning up previous Mininet state …"
sudo mn -c 2>/dev/null || true
pkill -f ryu-manager 2>/dev/null || true
sleep 1

# ── 2. Check dependencies ───────────────────────────────────
info "Checking dependencies …"

for cmd in ryu-manager python3 mn ovs-vsctl; do
    if ! command -v "$cmd" &>/dev/null; then
        error "Required command not found: $cmd"
        error "Install with:  sudo apt install mininet ryu python3 openvswitch-switch -y"
        exit 1
    fi
done
info "All dependencies found."

# ── 3. Start Ryu controller ─────────────────────────────────
info "Starting Ryu controller on port $RYU_PORT …"
ryu-manager \
    --ofp-tcp-listen-port "$RYU_PORT" \
    --verbose \
    "$CONTROLLER" \
    > "$LOG_DIR/ryu.log" 2>&1 &

RYU_PID=$!
echo "$RYU_PID" > "$LOG_DIR/ryu.pid"
info "Ryu PID = $RYU_PID  (logs → $LOG_DIR/ryu.log)"

# Wait for controller to be ready
for i in {1..10}; do
    if ss -tlnp | grep -q ":$RYU_PORT"; then
        info "Controller is listening on port $RYU_PORT."
        break
    fi
    sleep 1
done

# ── 4. Launch Mininet topology ──────────────────────────────
info "Launching Mininet topology + delay measurements …"
info "(This will open the Mininet CLI when done — type 'exit' to continue)"
sudo python3 "$TOPOLOGY"

# ── 5. Analysis report ──────────────────────────────────────
info "Running analysis …"
python3 "$ANALYSIS"

# ── 6. Flow table dump ─────────────────────────────────────
info "Dumping OpenFlow flow tables (saved to $LOG_DIR/flow_tables.txt) …"
{
    for switch in s1 s2 s3; do
        echo "===== $switch ====="
        sudo ovs-ofctl -O OpenFlow13 dump-flows "$switch" 2>/dev/null || echo "(switch not running)"
        echo ""
    done
} > "$LOG_DIR/flow_tables.txt" 2>&1
info "Flow tables saved."

# ── 7. Cleanup controller ───────────────────────────────────
info "Stopping Ryu controller (PID=$RYU_PID) …"
kill "$RYU_PID" 2>/dev/null || true

info "Done! All logs in: $LOG_DIR/"
echo ""
echo "  Files generated:"
echo "    $LOG_DIR/ryu.log          – controller output"
echo "    $LOG_DIR/controller.log   – packet_in / flow events"
echo "    $LOG_DIR/flow_events.json – per-flow JSON log"
echo "    $LOG_DIR/rtt_results.json – RTT measurements"
echo "    $LOG_DIR/flow_tables.txt  – ovs-ofctl dump"
echo ""
