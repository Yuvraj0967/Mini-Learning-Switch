#!/usr/bin/env python3
"""
Network Delay Measurement Tool - Custom Mininet Topology
Project 15 | Computer Networks Lab

Topology (multi-path, configurable link delays):

        10ms           10ms
  h1 ──────── s1 ──────────── s2 ──────── h2
               │               │
          20ms │               │ 20ms
               └───── s3 ──────┘
                      │
                 5ms  │
                      h3

  h4 ──────── s1  (5ms)

Hosts: h1 (10.0.0.1), h2 (10.0.0.2), h3 (10.0.0.3), h4 (10.0.0.4)
Switches: s1, s2, s3  (OpenFlow 1.3 / OVS)
Controller: Remote Ryu on 127.0.0.1:6633

Two measurable paths h1→h2:
  Path A (direct):  h1-s1-s2-h2   expected RTT ≈ 2*(10+10+10) = 60 ms
  Path B (via s3):  h1-s1-s3-s2-h2 expected RTT ≈ 2*(10+20+20+10) = 120 ms
"""

import sys
import time
import os
import json
from mininet.net import Mininet
from mininet.node import RemoteController, OVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel, info, error
from mininet.link import TCLink

# ── Link delay configuration (milliseconds) ──────────────────────────────
DELAYS = {
    "h1_s1": "10ms",   # host-to-switch
    "h2_s2": "10ms",
    "h3_s3": "5ms",
    "h4_s1": "5ms",
    "s1_s2": "10ms",   # direct switch-to-switch (Path A)
    "s1_s3": "20ms",   # via s3 (Path B)
    "s3_s2": "20ms",
}

CONTROLLER_IP   = "127.0.0.1"
CONTROLLER_PORT = 6633
LOG_DIR         = "logs"

# ─────────────────────────────────────────────────────────────────────────
def build_topology():
    """Construct and return the Mininet network object."""
    net = Mininet(
        controller = RemoteController,
        switch     = OVSSwitch,
        link       = TCLink,
        autoSetMacs = True,
    )

    info("*** Adding remote controller\n")
    c0 = net.addController(
        "c0",
        controller = RemoteController,
        ip         = CONTROLLER_IP,
        port       = CONTROLLER_PORT,
    )

    info("*** Adding switches\n")
    s1 = net.addSwitch("s1", protocols="OpenFlow13")
    s2 = net.addSwitch("s2", protocols="OpenFlow13")
    s3 = net.addSwitch("s3", protocols="OpenFlow13")

    info("*** Adding hosts\n")
    h1 = net.addHost("h1", ip="10.0.0.1/24")
    h2 = net.addHost("h2", ip="10.0.0.2/24")
    h3 = net.addHost("h3", ip="10.0.0.3/24")
    h4 = net.addHost("h4", ip="10.0.0.4/24")

    info("*** Adding links\n")
    # Host↔Switch links
    net.addLink(h1, s1, delay=DELAYS["h1_s1"])
    net.addLink(h2, s2, delay=DELAYS["h2_s2"])
    net.addLink(h3, s3, delay=DELAYS["h3_s3"])
    net.addLink(h4, s1, delay=DELAYS["h4_s1"])

    # Switch↔Switch links (two paths between s1 and s2)
    net.addLink(s1, s2, delay=DELAYS["s1_s2"])   # Path A (direct)
    net.addLink(s1, s3, delay=DELAYS["s1_s3"])   # Path B leg 1
    net.addLink(s3, s2, delay=DELAYS["s3_s2"])   # Path B leg 2

    return net


# ─────────────────────────────────────────────────────────────────────────
def run_delay_measurements(net):
    """
    Run ping-based RTT measurements between all host pairs and
    save results to logs/rtt_results.json.
    """
    os.makedirs(LOG_DIR, exist_ok=True)

    hosts = {
        "h1": net.get("h1"),
        "h2": net.get("h2"),
        "h3": net.get("h3"),
        "h4": net.get("h4"),
    }

    results = {}
    pairs = [
        ("h1", "h2"),  # main path-comparison pair
        ("h1", "h3"),
        ("h1", "h4"),
        ("h2", "h3"),
        ("h2", "h4"),
        ("h3", "h4"),
    ]

    info("\n" + "="*60 + "\n")
    info("  DELAY MEASUREMENT RESULTS\n")
    info("="*60 + "\n")

    for src_name, dst_name in pairs:
        src = hosts[src_name]
        dst = hosts[dst_name]
        dst_ip = dst.IP()

        info(f"  Measuring {src_name} → {dst_name} ({dst_ip})…\n")

        # 10 pings → parse min/avg/max/mdev
        output = src.cmd(f"ping -c 10 -i 0.2 {dst_ip}")

        rtts = _parse_ping(output)
        results[f"{src_name}_{dst_name}"] = rtts

        if rtts:
            info(
                f"    min={rtts['min']:.2f} avg={rtts['avg']:.2f} "
                f"max={rtts['max']:.2f} mdev={rtts['mdev']:.2f} ms\n"
            )
        else:
            info("    ⚠  No RTT data (ping failed)\n")

    # Save
    out_path = os.path.join(LOG_DIR, "rtt_results.json")
    with open(out_path, "w") as f:
        json.dump({"timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
                   "delays_config": DELAYS,
                   "results": results}, f, indent=2)

    info(f"\n  Results saved → {out_path}\n")
    info("="*60 + "\n")
    return results


def _parse_ping(output):
    """Extract min/avg/max/mdev from ping output string."""
    import re
    pattern = r"rtt min/avg/max/mdev = ([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+)"
    m = re.search(pattern, output)
    if m:
        return {
            "min" : float(m.group(1)),
            "avg" : float(m.group(2)),
            "max" : float(m.group(3)),
            "mdev": float(m.group(4)),
        }
    return None


# ─────────────────────────────────────────────────────────────────────────
def run_test_scenarios(net):
    """
    Scenario 1 – Normal connectivity (all hosts pingable).
    Scenario 2 – Simulated link failure on s1↔s2 direct path,
                 traffic should re-path via s3 (higher RTT).
    """
    info("\n" + "="*60 + "\n")
    info("  TEST SCENARIO 1: Normal Connectivity\n")
    info("="*60 + "\n")

    h1 = net.get("h1")
    h2 = net.get("h2")

    out = h1.cmd("ping -c 5 10.0.0.2")
    info(out + "\n")

    info("="*60 + "\n")
    info("  TEST SCENARIO 2: Simulated Link Disruption (h1→h2)\n")
    info("="*60 + "\n")
    info("  (Introducing artificial 50ms extra delay on h1's interface)\n")

    # Add netem delay to simulate congestion/degradation
    h1.cmd("tc qdisc add dev h1-eth0 root netem delay 50ms 10ms")
    out = h1.cmd("ping -c 5 10.0.0.2")
    info(out + "\n")

    # Remove the extra delay
    h1.cmd("tc qdisc del dev h1-eth0 root")

    info("  Link restored to normal.\n")
    info("="*60 + "\n")


# ─────────────────────────────────────────────────────────────────────────
def main():
    setLogLevel("info")

    info("*** Building multi-path topology\n")
    net = build_topology()

    info("*** Starting network\n")
    net.start()

    # Brief pause to let controller connect and push flows
    info("*** Waiting for controller to connect (5 s)…\n")
    time.sleep(5)

    # Basic connectivity check
    info("*** Running pingAll (connectivity check)\n")
    net.pingAll()

    # Delay measurements
    run_delay_measurements(net)

    # Test scenarios
    run_test_scenarios(net)

    # Drop into CLI for manual exploration
    info("\n*** Dropping into Mininet CLI (type 'exit' to quit)\n")
    CLI(net)

    info("*** Stopping network\n")
    net.stop()


if __name__ == "__main__":
    main()
