#!/usr/bin/env python3
"""
Network Delay Measurement Tool - Standalone Measurement Script
Project 15 | Computer Networks Lab

This script can be executed INSIDE Mininet's Python API
(e.g. called via net.get('h1').cmd('python3 delay_measure.py'))
OR run directly from the Mininet CLI as:

  mininet> py exec(open('measurement/delay_measure.py').read())

It performs:
  • Repeated ping measurements (configurable count)
  • RTT recording per (src, dst) pair
  • Jitter (mdev) tracking
  • CSV export for further analysis
"""

import subprocess
import re
import json
import csv
import time
import os
import sys

PING_COUNT   = 15          # pings per pair
PING_INTERVAL = 0.3        # seconds between pings
OUTPUT_DIR   = "logs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────
def ping_measure(src_host, dst_ip, count=PING_COUNT, interval=PING_INTERVAL):
    """
    Run ping from src_host to dst_ip.
    src_host: Mininet Host object or None (runs on local machine).
    Returns dict with RTT statistics.
    """
    cmd = f"ping -c {count} -i {interval} {dst_ip}"

    if src_host is not None:
        # Running inside Mininet
        output = src_host.cmd(cmd)
    else:
        # Running standalone
        result = subprocess.run(cmd.split(), capture_output=True, text=True)
        output = result.stdout + result.stderr

    return _parse_output(output, dst_ip)


def _parse_output(output, dst_ip):
    """Extract RTT stats and packet loss from ping output."""
    result = {
        "dst_ip"      : dst_ip,
        "timestamp"   : time.strftime("%Y-%m-%dT%H:%M:%S"),
        "sent"        : None,
        "received"    : None,
        "loss_pct"    : None,
        "min_ms"      : None,
        "avg_ms"      : None,
        "max_ms"      : None,
        "mdev_ms"     : None,
        "raw_rtts"    : [],
    }

    # Individual RTT values
    rtt_pattern = re.compile(r"time=([\d.]+)\s*ms")
    result["raw_rtts"] = [float(m) for m in rtt_pattern.findall(output)]

    # Summary line
    stats_pattern = re.compile(
        r"rtt min/avg/max/mdev = ([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+)"
    )
    m = stats_pattern.search(output)
    if m:
        result["min_ms"]  = float(m.group(1))
        result["avg_ms"]  = float(m.group(2))
        result["max_ms"]  = float(m.group(3))
        result["mdev_ms"] = float(m.group(4))

    # Packet loss
    loss_pattern = re.compile(r"(\d+) packets transmitted, (\d+) received.*?([\d.]+)% packet loss")
    lm = loss_pattern.search(output)
    if lm:
        result["sent"]     = int(lm.group(1))
        result["received"] = int(lm.group(2))
        result["loss_pct"] = float(lm.group(3))

    return result


# ─────────────────────────────────────────────────────────────────────────
def measure_all_pairs(net=None):
    """
    Measure RTT for all host pairs.
    If net is None, uses localhost (for standalone testing).
    """
    if net:
        hosts_map = {name: net.get(name) for name in ["h1", "h2", "h3", "h4"]}
        ip_map    = {name: h.IP() for name, h in hosts_map.items()}
    else:
        # Standalone mode: measure from this machine to target IPs
        hosts_map = {"local": None}
        ip_map    = {"h1": "10.0.0.1", "h2": "10.0.0.2"}

    pairs = [
        ("h1", "h2"),
        ("h1", "h3"),
        ("h1", "h4"),
        ("h2", "h3"),
        ("h2", "h4"),
        ("h3", "h4"),
    ]

    all_results = []

    print("\n" + "─" * 55)
    print(f"  Delay Measurement  |  {PING_COUNT} pings per pair")
    print("─" * 55)

    for src_name, dst_name in pairs:
        if net:
            src_host = hosts_map[src_name]
            dst_ip   = ip_map[dst_name]
        else:
            src_host = None
            dst_ip   = ip_map.get(dst_name, "127.0.0.1")

        print(f"  {src_name} → {dst_name} ({dst_ip}) … ", end="", flush=True)
        r = ping_measure(src_host, dst_ip)
        r["src"] = src_name
        r["dst"] = dst_name
        all_results.append(r)

        if r["avg_ms"] is not None:
            print(
                f"avg={r['avg_ms']:.2f}ms  "
                f"min={r['min_ms']:.2f}ms  "
                f"max={r['max_ms']:.2f}ms  "
                f"jitter={r['mdev_ms']:.2f}ms  "
                f"loss={r['loss_pct']}%"
            )
        else:
            print("FAILED (no RTT data)")

    print("─" * 55 + "\n")

    _save_json(all_results)
    _save_csv(all_results)
    _print_variation_analysis(all_results)

    return all_results


# ─────────────────────────────────────────────────────────────────────────
def _save_json(results):
    path = os.path.join(OUTPUT_DIR, "rtt_results.json")
    with open(path, "w") as f:
        json.dump({
            "timestamp"    : time.strftime("%Y-%m-%dT%H:%M:%S"),
            "ping_count"   : PING_COUNT,
            "results"      : {
                f"{r['src']}_{r['dst']}": {
                    "min" : r["min_ms"],
                    "avg" : r["avg_ms"],
                    "max" : r["max_ms"],
                    "mdev": r["mdev_ms"],
                    "loss": r["loss_pct"],
                }
                for r in results if r["avg_ms"] is not None
            },
        }, f, indent=2)
    print(f"  JSON results → {path}")


def _save_csv(results):
    path = os.path.join(OUTPUT_DIR, "rtt_results.csv")
    fieldnames = ["src", "dst", "dst_ip", "timestamp",
                  "sent", "received", "loss_pct",
                  "min_ms", "avg_ms", "max_ms", "mdev_ms"]
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)
    print(f"  CSV  results → {path}")


def _print_variation_analysis(results):
    """Print delay variation / jitter analysis."""
    print("\n  ▸ Delay Variation Analysis")
    print("  " + "─" * 50)
    for r in results:
        if r["avg_ms"] is None:
            continue
        variation_pct = (r["mdev_ms"] / r["avg_ms"] * 100) if r["avg_ms"] else 0
        level = ("LOW   " if variation_pct < 5
                 else "MEDIUM" if variation_pct < 15
                 else "HIGH  ")
        print(
            f"    {r['src']}→{r['dst']:<4}  "
            f"avg={r['avg_ms']:>6.2f}ms  "
            f"jitter={r['mdev_ms']:>5.2f}ms  "
            f"({variation_pct:>5.1f}%)  → {level}"
        )
    print()


# ─────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Standalone mode (for unit-testing without Mininet)
    print("Running in standalone mode (not inside Mininet).")
    print("To use inside Mininet, import and call measure_all_pairs(net).")
    measure_all_pairs(net=None)
