# Network Delay Measurement Tool
### Project 15 — SDN / Mininet Lab | Computer Networks

> **SDN-based latency measurement and analysis using Mininet + OpenFlow 1.3 + Ryu controller**

---

## Problem Statement

Design and implement a network delay measurement tool using an SDN framework that:
- Uses **ping (ICMP)** for RTT (Round-Trip Time) measurement between hosts
- **Records RTT values** (min / avg / max / mdev) for each host pair
- **Compares latency across multiple paths** in a multi-path topology
- **Analyzes delay variations** (jitter) to assess network stability

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     Ryu Controller (SDN)                    │
│         delay_controller.py  |  OpenFlow 1.3               │
│  - Handles packet_in events                                 │
│  - MAC learning & flow rule installation                    │
│  - Match+action: in_port + eth_src + eth_dst → output_port │
└──────────────────────┬──────────────────────────────────────┘
                       │  OpenFlow channel (TCP 6633)
        ┌──────────────┼──────────────────┐
        │              │                  │
      [s1]           [s2]              [s3]
     /    \          /    \           /     \
   h1     h4      h2      (links to s1 & s3)
                         h3 (via s3)
```

### Topology (Multi-path)

```
        10ms           10ms
  h1 ──────── s1 ──────────── s2 ──────── h2
   (10.0.0.1)  │               │  (10.0.0.2)
          20ms │               │ 20ms
               └───── s3 ──────┘
                5ms   │
                      h3 (10.0.0.3)
  h4 ──── 5ms ─── s1
(10.0.0.4)
```

**Two measurable paths (h1 → h2):**
| Path | Route | Expected RTT |
|------|-------|-------------|
| Path A (direct) | h1 → s1 → s2 → h2 | ≈ 60 ms |
| Path B (via s3) | h1 → s1 → s3 → s2 → h2 | ≈ 120 ms |

---

## Project Structure

```
project/
├── controller/
│   └── delay_controller.py    # Ryu SDN controller
├── topology/
│   └── network_topology.py    # Mininet multi-path topology
├── measurement/
│   └── delay_measure.py       # RTT measurement & CSV/JSON export
├── analysis/
│   └── analyze_results.py     # Report & delay variation analysis
├── logs/                      # Auto-created; all output files
├── run.sh                     # One-command orchestration script
└── README.md
```

---

## Setup & Execution Steps

### Prerequisites

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Mininet
sudo apt install mininet -y

# Install Ryu SDN framework
pip3 install ryu --break-system-packages

# Install Open vSwitch (usually bundled with Mininet)
sudo apt install openvswitch-switch -y

# Verify Mininet
sudo mn --test pingall
```

### Running the Full Experiment

```bash
# Clone this repository
git clone https://github.com/<your-username>/network-delay-tool.git
cd network-delay-tool

# Make run script executable
chmod +x run.sh

# Run everything (requires sudo for Mininet)
sudo ./run.sh
```

This script:
1. Cleans up any existing Mininet state (`mn -c`)
2. Starts the **Ryu controller** in background
3. Launches the **Mininet topology** with configurable TCLink delays
4. Runs **pingAll** connectivity check
5. Executes **RTT measurements** (10 pings per host pair)
6. Runs **test scenarios** (normal + degraded link)
7. Dumps **flow tables** via `ovs-ofctl`
8. Runs **analysis report**

---

### Running Components Individually

#### Start controller only:
```bash
ryu-manager --ofp-tcp-listen-port 6633 --verbose controller/delay_controller.py
```

#### Start topology only (controller must be running):
```bash
sudo python3 topology/network_topology.py
```

#### From Mininet CLI — manual RTT test:
```
mininet> h1 ping -c 10 h2
mininet> h1 ping -c 10 h3
mininet> pingall
```

#### Dump flow tables from CLI:
```
mininet> sh ovs-ofctl -O OpenFlow13 dump-flows s1
mininet> sh ovs-ofctl -O OpenFlow13 dump-flows s2
```

#### Run analysis after experiment:
```bash
python3 analysis/analyze_results.py
```

---

## Expected Output

### Connectivity Check
```
*** Running pingAll
h1 -> h2 h3 h4
h2 -> h1 h3 h4
h3 -> h1 h2 h4
h4 -> h1 h2 h3
*** Results: 0% dropped (12/12 received)
```

### Delay Measurement Results
```
══════════════════════════════════════════════════════════════
  DELAY MEASUREMENT REPORT
══════════════════════════════════════════════════════════════
  Pair       Min(ms)  Avg(ms)  Max(ms)  Jitter   Status
  ──────────────────────────────────────────────────────────
  h1→h2       58.12    62.35    68.90     2.10  [ PASS ]
  h1→h3       65.44    70.12    75.30     2.50  [ PASS ]
  h1→h4       26.80    30.22    34.10     1.20  [ PASS ]
  h2→h3       63.10    68.44    73.20     2.30  [ PASS ]
  h2→h4       42.50    48.10    53.80     2.00  [ PASS ]
  h3→h4       52.10    57.44    62.30     1.90  [ PASS ]
```

### Flow Table Entry Example
```
cookie=0x0, duration=12.345s, table=0, n_packets=10,
priority=1,in_port=1,dl_src=00:00:00:00:00:01,
dl_dst=00:00:00:00:00:02 actions=output:2
```

---

## Test Scenarios

### Scenario 1 – Normal Connectivity
All hosts can reach each other. RTT values match expected topology delays.

```bash
# From Mininet CLI
mininet> pingall
```
**Expected:** 0% packet loss across all pairs.

---

### Scenario 2 – Simulated Link Degradation
Extra delay injected on h1's interface using Linux `tc netem` to simulate congestion.

```bash
# Inject 50ms extra delay + 10ms variation
h1 tc qdisc add dev h1-eth0 root netem delay 50ms 10ms

# Measure impact
h1 ping -c 5 10.0.0.2
# Expected RTT ≈ 160ms (60ms base + 50ms×2 injected)

# Remove degradation
h1 tc qdisc del dev h1-eth0 root
```

| Scenario | Expected RTT h1→h2 |
|----------|-------------------|
| Normal   | ≈ 60 ms           |
| Degraded | ≈ 160 ms          |

---

## Proof of Execution (Screenshots/Logs)

After running, the following files are generated in `logs/`:

| File | Contents |
|------|----------|
| `ryu.log` | Full Ryu controller output |
| `controller.log` | packet_in events, flow installations |
| `flow_events.json` | Per-flow JSON log (dpid, MACs, ports) |
| `rtt_results.json` | RTT stats per host pair |
| `rtt_results.csv` | Same data in CSV format |
| `flow_tables.txt` | `ovs-ofctl dump-flows` for s1/s2/s3 |

---

## Controller Logic Summary

```python
# On switch connect → install table-miss rule
match = OFPMatch()            # match everything
actions = [output(CONTROLLER)]  # send to controller
add_flow(priority=0, ...)

# On packet_in → learn MAC, install unicast rule
match = OFPMatch(in_port=X, eth_src=SRC, eth_dst=DST)
actions = [output(known_port)]
add_flow(priority=1, idle_timeout=60, ...)
```

---

## Dependencies

| Package | Purpose |
|---------|---------|
| `mininet` | Network emulation |
| `ryu` | SDN controller framework |
| `openvswitch-switch` | Virtual switch (OVS) |
| `python3` | Scripting |
| `iproute2` / `tc` | Link delay manipulation (netem) |
| `wireshark` / `tshark` | Optional: packet capture |
| `iperf3` | Optional: bandwidth testing |

---

## Cleanup

```bash
# Clean up Mininet state
sudo mn -c

# Kill Ryu controller
pkill -f ryu-manager
```

---

## Author
**[Your Name]** | Roll No: [Your Roll No]  
Course: Computer Networks Lab | Batch: [Your Batch]
