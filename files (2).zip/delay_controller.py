"""
Network Delay Measurement Tool - SDN Controller
Project 15 | Computer Networks Lab
Controller: Ryu | Protocol: OpenFlow 1.3

This Ryu controller:
  - Handles packet_in events from all switches
  - Learns MAC→port mappings dynamically
  - Installs explicit match+action flow rules
  - Logs per-flow information for delay analysis
"""

import logging
import time
import json
import os
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet, arp, ipv4, icmp, ether_types
from ryu.lib import hub

LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)

# ────────────────────────────────────────────────────────────────────────────
class DelayMeasurementController(app_manager.RyuApp):
    """
    L2 learning switch with OpenFlow 1.3 flow rules.
    Tracks packet_in events and installs match+action entries
    so that subsequent traffic is handled in the data plane.
    """

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # { dpid : { mac_addr : port } }
        self.mac_to_port = {}

        # Flow event log for analysis
        self.flow_log = []

        # Per-switch stats
        self.switch_info = {}

        logging.basicConfig(
            filename=os.path.join(LOG_DIR, "controller.log"),
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(message)s",
        )
        self.logger.setLevel(logging.DEBUG)
        self.logger.info("DelayMeasurementController started")

        # Background thread: dump flow log every 10 s
        self.monitor_thread = hub.spawn(self._save_flow_log_periodically)

    # ── Switch handshake ──────────────────────────────────────────────────
    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        """
        Called once per switch when it connects.
        Installs a table-miss rule (priority 0) that sends unmatched
        packets to the controller.
        """
        datapath = ev.msg.datapath
        ofproto  = datapath.ofproto
        parser   = datapath.ofproto_parser
        dpid     = datapath.id

        self.mac_to_port.setdefault(dpid, {})
        self.switch_info[dpid] = {"connected_at": time.time(), "flow_count": 0}

        self.logger.info("Switch connected: dpid=%016x", dpid)

        # Table-miss entry: send everything to controller
        match   = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                          ofproto.OFPCML_NO_BUFFER)]
        self._add_flow(datapath, priority=0, match=match, actions=actions)

    # ── Helper: install a flow rule ───────────────────────────────────────
    def _add_flow(self, datapath, priority, match, actions,
                  buffer_id=None, idle_timeout=60, hard_timeout=0):
        """
        Send an OFPFlowMod message to install a match+action rule
        on the target datapath (switch).
        """
        ofproto = datapath.ofproto
        parser  = datapath.ofproto_parser

        instructions = [
            parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)
        ]

        kwargs = dict(
            datapath     = datapath,
            priority     = priority,
            match        = match,
            instructions = instructions,
            idle_timeout = idle_timeout,
            hard_timeout = hard_timeout,
        )
        if buffer_id and buffer_id != ofproto.OFP_NO_BUFFER:
            kwargs["buffer_id"] = buffer_id

        mod = parser.OFPFlowMod(**kwargs)
        datapath.send_msg(mod)

        dpid = datapath.id
        if dpid in self.switch_info:
            self.switch_info[dpid]["flow_count"] += 1

        self.logger.info(
            "FlowMod installed | dpid=%016x priority=%d idle_timeout=%ds",
            dpid, priority, idle_timeout,
        )

    # ── packet_in handler ─────────────────────────────────────────────────
    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in_handler(self, ev):
        """
        Handles packets sent to the controller (table-miss or ARP).

        Logic:
          1. Learn src MAC → in_port mapping.
          2. If dst MAC is known  → output on known port and install flow rule.
          3. If dst MAC is unknown → flood.
        """
        msg      = ev.msg
        datapath = msg.datapath
        ofproto  = datapath.ofproto
        parser   = datapath.ofproto_parser
        in_port  = msg.match["in_port"]
        dpid     = datapath.id

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]

        # Ignore LLDP (link-layer discovery)
        if eth.ethertype == ether_types.ETH_TYPE_LLDP:
            return

        dst = eth.dst
        src = eth.src

        # ── 1. Learn MAC ──
        self.mac_to_port.setdefault(dpid, {})
        self.mac_to_port[dpid][src] = in_port

        # ── 2. Determine output port ──
        if dst in self.mac_to_port[dpid]:
            out_port = self.mac_to_port[dpid][dst]
        else:
            out_port = ofproto.OFPP_FLOOD

        actions = [parser.OFPActionOutput(out_port)]

        # ── 3. Install flow rule (only for unicast) ──
        if out_port != ofproto.OFPP_FLOOD:
            match = parser.OFPMatch(
                in_port = in_port,
                eth_dst = dst,
                eth_src = src,
            )
            self._add_flow(
                datapath,
                priority     = 1,
                match        = match,
                actions      = actions,
                buffer_id    = msg.buffer_id,
                idle_timeout = 60,
            )

        # Log the packet_in event
        self._log_packet_in(dpid, src, dst, in_port, out_port, eth.ethertype)

        # ── 4. Send the buffered packet out ──
        if msg.buffer_id == ofproto.OFP_NO_BUFFER:
            data = msg.data
        else:
            data = None

        out = parser.OFPPacketOut(
            datapath  = datapath,
            buffer_id = msg.buffer_id,
            in_port   = in_port,
            actions   = actions,
            data      = data,
        )
        datapath.send_msg(out)

        self.logger.info(
            "PacketIn | dpid=%016x src=%s dst=%s in_port=%d out_port=%s",
            dpid, src, dst, in_port,
            out_port if out_port != ofproto.OFPP_FLOOD else "FLOOD",
        )

    # ── Logging helpers ───────────────────────────────────────────────────
    def _log_packet_in(self, dpid, src, dst, in_port, out_port, ethertype):
        entry = {
            "timestamp" : time.strftime("%Y-%m-%dT%H:%M:%S"),
            "dpid"      : f"{dpid:016x}",
            "src_mac"   : src,
            "dst_mac"   : dst,
            "in_port"   : in_port,
            "out_port"  : out_port,
            "ethertype" : hex(ethertype),
        }
        self.flow_log.append(entry)

    def _save_flow_log_periodically(self):
        while True:
            hub.sleep(10)
            path = os.path.join(LOG_DIR, "flow_events.json")
            try:
                with open(path, "w") as f:
                    json.dump(self.flow_log, f, indent=2)
            except Exception as e:
                self.logger.error("Failed to write flow log: %s", e)
